/*
Author: RUFUS OLUDARE C2676906
Author: MD SARWAR AHMED W9608149

*/
package oop.ica.e1;

/*This code imports the necessary classes from the Java Standard Library 
for working with ArrayLists and reading user input from the console.*/
import java.util.ArrayList;
import static java.nio.file.StandardOpenOption.*;
import java.nio.file.Path;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.InputMismatchException;
import java.util.Scanner;

public class SportsShopSystem {
    
    //This line of code creates a new ArrayList object named "storedData" that can hold elements of the SportsShopSystem type
    private static ArrayList<SportsShopSystem> storedData;
    
    private static final String DELIMITER = ",";
    
    String productCode;
    String productTitle;
    String productDescription;
    int pricePence;
    int stockQuantity;
    int pricePounds;
    
    /*This methods are declared as public, meaning that
    it can be accessed from other classes and methods.*/
    public int getStockQuantity() {
        return stockQuantity;
    }
    
    public int getPricePounds(){
        return pricePounds;
    }
    
    public int getPricePence(){
        return pricePence;
    }
    
    public String getProductCode(){
        return productCode;
    }
    
    public String getProductTitle(){
        return productTitle;
    }
    
    public String getProductDescription(){
        return productDescription;
    }
    
    /*this constructor provides a way to create new SportsShopSystem objects 
    with specific attributes and initial values, which can be stored in the
    storedData ArrayList.*/
    public SportsShopSystem(String productCode, String productTitle, String productDescription, int pricePounds, int pricePence, int stockQuantity){
        this.productCode = productCode;
        this.productTitle = productTitle;
        this.productDescription = productDescription;
        this.pricePounds = pricePounds;
        this.pricePence = pricePence;
        this.stockQuantity = stockQuantity;
    }
    
    public SportsShopSystem() {
        
    }
    
    public static void menu() {
        
        Scanner sc = new Scanner(System.in); 
        SportsShopSystem sportsShopSystem = new SportsShopSystem();
        boolean terminate = false;
        int selection;
        //try to load the data csv file
        try{
              loadData();
            }catch(FileNotFoundException e) {
                System.out.println("\n\n!!!!!Unable to open file!!!!!" + e.getMessage() + "\n");
                System.exit(0);
            }catch(IOException e) {
                System.out.print("\n\n!!!!! file read error!!!!!\n " + e.getMessage() + "\n");
                System.exit(0);
            }
        
        //printing out the menu header
        System.out.println("ASHER SPORT CONSORTIUM \n");
        
        
        
        try {
            do {
                


                System.out.println("MAIN MENU: Please select a menu option to continue" );
                System.out.println( "\t[1] View Items ");
                System.out.println( "\t[2] Buy Items ");
                System.out.println( "\t[3] Add Stock ");
                System.out.println( "\t[0] Quit \n");
        
                System.out.println("Please enter a number: ");
        
                
                selection = sc.nextInt();
        
        
                switch (selection) {
                    case 0:
                        quit();
                        terminate = true;
                        break;       
    
                    case 1:
                        viewItems();
                        sportsShopSystem.displayItems(storedData, "view");
                        break;
                    case 2:
                        buyItems();
                        sportsShopSystem.displayItems(storedData, "buy");
                        
                        System.out.println("\nSelect the item you want to buy, or 0 to return to main menu");
                        selection = sc.nextInt();
                        
                        if (selection != 0) {
                            int index = selection - 1;
                            if(storedData.get(index).getStockQuantity() > 0) {
                                sportsShopSystem.modifyStock(storedData, "buy", index);
                            } else 
                                if( storedData.get(index).getStockQuantity() == 0) {
                                System.out.println(storedData.get(index).getProductTitle() + " is out of stock");   
                            }
                        }
                        break;
                        
                        case 3:
                            addStock();
                            System.out.println("Stock Items");
                            sportsShopSystem.displayItems(storedData, "add");
                            
                            System.out.println("\nSelect item to add, or 0 to return to main menu");
                            selection = sc.nextInt();
                            
                            if(selection != 0) {
                                int index = selection - 1;
                                sportsShopSystem.modifyStock(storedData, "add", index);
                            }
                            break;
                            
                        default:
                            System.out.println("!!!!! please select a Valid menu option to continue !!!!! \n" );
                }
            } 
            
            
            while(terminate != true );
        }
        catch(InputMismatchException | IndexOutOfBoundsException ex) {
            System.out.println("!!!!! Please select a Valid menu option to continue !!!!!");
            menu();    
        }
    }
    
    
    /*methods for to print view items, buyItems, addStock, */
    public static void viewItems(){
            System.out.println("1 \n");
            System.out.println("View Items \n");
    }
    
    public static void buyItems(){
            System.out.println("2 \n");
            System.out.println("Buy Items \n");
    }
    
    public static void addStock(){
            System.out.println("3 \n");
            System.out.println("Add Stock \n");
    }
    
    public static void quit(){
        //try to save the data into the file and warn the user if there are any errors
            try{
                saveData();
            } catch (FileNotFoundException e){
                System.out.println("\n\n!!!!!Unable to open output file !!!!!\n" + e.getMessage());
            } catch(IOException e){
                System.out.println("\n\n!!!!!File write error !!!!!\n" + e.getMessage() +"\n");
            }
                    
            
            System.out.println("***** Thank you for your visit ***** \n" );
    }
    
    
    public static void main(String[] args) {
        menu();
    }
    
    /*This code defines a private method named loadData. The method is used to load
    sample data into the storedData ArrayList if it is empty.*/
    private static void loadData() throws IOException, FileNotFoundException  {
        final String INPUT_FILE_PATH = "AsherSportsConsortium.csv";
        File inputFile = new File(INPUT_FILE_PATH);
        Scanner fileScanner;
        storedData = new ArrayList();
        
        if ( inputFile.exists() && inputFile.isFile() ) {
            //set scanner to be file object
            fileScanner = new Scanner(inputFile);
            
            while (fileScanner.hasNextLine()) {
                //read and trim line
                String Line = fileScanner.nextLine().trim();
                //chech line has cotent
                if (!Line.isEmpty()) {
                    String stockCode = Line.split(DELIMITER)[0];
                    String Title = Line.split(DELIMITER)[1];
                    String Description = Line.split(DELIMITER)[2];
                    int StockPrice = Integer.parseInt(Line.split(DELIMITER)[3]);
                    int StockPricePence = Integer.parseInt(Line.split(DELIMITER)[4]);
                    int Quantity = Integer.parseInt(Line.split(DELIMITER)[5]);
                    //add data to the arraylist
                    storedData.add(new SportsShopSystem(stockCode, Title, Description, StockPrice,StockPricePence, Quantity ));
                }
            }
            //close file stream by closing scanner
            fileScanner.close();
        }
        else {
            System.out.println("\n !!!!! ERROR: '" + inputFile.getName() + "' does not exist as a data file. !!!!! \n");
            System.exit(0);
        }
            
            
            
        
//        if(storedData.isEmpty()) {
//            storedData.add(new SportsShopSystem("RUN1234567", "RunTech Shorts", "High quality running shorts", 10, 0, 10));
//            storedData.add(new SportsShopSystem("CYC1111111", "Cycle4ever Cycling Jacket", "Ultra lightweight jacket for te urban cyclist", 50, 0, 20));
//            storedData.add(new SportsShopSystem("SWM2222222", "7oceans Googles", "Super HiTech googles for the extreme swimmer", 24, 99, 8));
//        }
        
        //return storedData;
    }
    
    /*The method is used to display the items in the sports shop
    system either in a detailed view or a summary view, depending
    on the value of the action parameter.*/
    private ArrayList displayItems(ArrayList<SportsShopSystem> storedData, String action) {
        if (action.equals("view")){
            System.out.println("Stock Code" + "\t" + String.format("%-30s", "Title") + "\t"
                + String.format("%-100s", "Description") + "\t" + "Price" + "\t" + "Quantity" );
            for (int a = 0; a < storedData.size(); a++) {
                SportsShopSystem dataOut = storedData.get(a);
                Double stockPrice = Double.valueOf(dataOut.getPricePounds() + "." + dataOut.getPricePence());
                String PriceFormatted = String.format("%,.2f", stockPrice);
                System.out.println(storedData.get(a).getProductCode() + "\t" + String.format("%-30s",dataOut.getProductTitle()) + "\t"
                        + String.format("%-100s", dataOut.getProductDescription()) + "\t" + "£" + PriceFormatted + "\t" + dataOut.getStockQuantity());
            }
            
        } else {
            System.out.println("ID" + "\t" + String.format("%-30s", "Item") + "\t" + "Price" + "\t" + "Quantity");
            for(int a = 0; a < storedData.size(); a++) {
                int b = 1 + a;
                SportsShopSystem dataOut = storedData.get(a);
                Double stockPrice = Double.valueOf(dataOut.getPricePounds() + "." + dataOut.getPricePence());
                String PriceFormatted = String.format("%,.2f", stockPrice);
                System.out.println(b + "\t" + String.format("%-30s", dataOut.getProductTitle()) + "\t£" 
                        + PriceFormatted + "\t" + dataOut.getStockQuantity());
            }
        }
        System.out.println("");
        return storedData;
    }
    
    /*The modifyStock method is used to modify the quantity of
    items in the inventory based on the specified action
    ("buy" or "add") and the index of the item to modify.*/
    private ArrayList modifyStock (ArrayList<SportsShopSystem> storedData, String action, int index) {
        if (action.equals("buy")) {
            if(storedData.get(index).getStockQuantity() > 0) {
                int newQuantity = storedData.get(index).getStockQuantity() - 1;
                storedData.set(index, new SportsShopSystem(storedData.get(index).getProductCode(),storedData.get(index).getProductTitle(),
                storedData.get(index).getProductDescription(), storedData.get(index).getPricePounds(),
                storedData.get(index).getPricePence(), newQuantity ));
                
                Double buyingPrice = Double.valueOf(storedData.get(index).getPricePounds() + "." + storedData.get(index).getPricePence());
                String PriceFormatted = String.format("£%,.2f", buyingPrice);
                System.out.println("Sale of " + storedData.get(index).getProductTitle() + " for " +
                PriceFormatted + " confirmed. Quantity remaining: " + storedData.get(index).getStockQuantity());
            }
           
        }
        
        if (action.equals("add")) {
            int newQuantity = storedData.get(index).getStockQuantity() + 1;
            storedData.set(index, new SportsShopSystem(storedData.get(index).getProductCode(), storedData.get(index).getProductTitle(),
            storedData.get(index).getProductDescription(), storedData.get(index).getPricePounds(), storedData.get(index).getPricePence(), newQuantity ));
            
            System.out.println("New Quantity of " + storedData.get(index).getProductTitle() + " is: " + 
                    storedData.get(index).getStockQuantity());
        }
        
        return storedData;
    }
    
    public static void saveData() throws IOException, FileNotFoundException {
        final String OUTPUT_FILE_PATH = "AsherSportsConsortium.csv";
        
        Path path = Paths.get(OUTPUT_FILE_PATH);
        
        Files.deleteIfExists(path);
        
        
        BufferedOutputStream buffer = new BufferedOutputStream(
        Files.newOutputStream(path, CREATE, WRITE)
        );
        
        //output string
        String report ="";
        
        //loop through arraylist
        for (int index = 0; index < storedData.size(); index++) {
            //add field of current stored data to string, followed by the delimiter
            report += storedData.get(index).getProductCode() + DELIMITER;
            report += storedData.get(index).getProductTitle() + DELIMITER;
            report += storedData.get(index).getProductDescription() + DELIMITER;
            report += storedData.get(index).getPricePounds() + DELIMITER;
            report += storedData.get(index).getPricePence() + DELIMITER;
            report += storedData.get(index).getStockQuantity() + "\r\n";
        } //end of loop
        //transform output sring to byte array
        byte  data[] = report.getBytes();
        
        //write byte array to the stream
        buffer.write(data, 0, data.length);
        
       //close buffer so stream writes to file
       buffer.close();
       
       //confirm data written
       System.out.println("\n\nData written to file at:" + path.toAbsolutePath().toString());
    }

}


